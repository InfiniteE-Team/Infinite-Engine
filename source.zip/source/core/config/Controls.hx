package core.config;

class Controls
{
    public function new()
    {
        super();
    }
}