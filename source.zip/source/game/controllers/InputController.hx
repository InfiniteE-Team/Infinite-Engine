package game.controllers;

class InputController
{
    public var inputNotes:Array<Bool> = [FlxG.keys.pressed.A,FlxG.keys.pressed.W,FlxG.keys.pressed.S,FlxG.keys.pressed.D];

    public function new() {}
}