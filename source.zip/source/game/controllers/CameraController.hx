class CameraController
{
    // yep
}